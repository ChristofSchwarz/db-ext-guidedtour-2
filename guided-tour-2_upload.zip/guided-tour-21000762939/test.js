
function evaluate(inp) {
    return inp + inp
}

var v = 'ab $(cd) ef $(=Pi()) ik';
var needle = 0;
parts = [];

while (v.indexOf('$(', needle) > -1) {
    needle = v.indexOf('$(', needle);
    console.log('found at ', needle);
    parts.push(v.substr(0, needle));
    const start = needle + 2;
    needle = needle + 2;
    bracketLevel = 1;
    do {
        //console.log('inspecting ', v.substr(needle, 1), bracketLevel);
        if (v.substr(needle, 1) == '(') bracketLevel++;
        if (v.substr(needle, 1) == ')') bracketLevel--;
        needle++;
    } while (needle <= v.length && bracketLevel > 0)
    const end = needle;
    if (bracketLevel > 0) {
        console.error('bracket level starting at ' + start + ' does not close');
    } else {
        console.log('brackets close at ', end, v.substr(start, end - start - 1));
        needle += v.length;
        v = v.substr(0, start - 2)
            + evaluate(v.substr(start, end - start - 1))
            + v.substr(end);
        needle -= v.length;
    }
    needle++;
}
console.log('done', v);